--
-- Database: `patialagov`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `age` varchar(10) NOT NULL,
  `sex` enum('Male','Female','','') NOT NULL DEFAULT 'Male',
  `meeting_purpose` longtext NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `employee_id` int(11) NOT NULL,
  `time_slot` int(11) NOT NULL,
  `booking_status` enum('Pending','Accepted','Canceled','') NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `email`, `age`, `sex`, `meeting_purpose`, `phone_no`, `date`, `employee_id`, `time_slot`, `booking_status`, `created_at`, `updated_at`) VALUES
(14, 'Palmer Franco', 'wijyr@yahoo.com', 'Possimus d', 'Female', 'Nihil dicta laborum facilis nisi asperiores autem a nisi iusto et modi ullam maxime tempor eius non enim.', '+634-52-2278740', '2017-05-10', 948, 3, 'Pending', '2017-05-09 15:10:56', '2017-05-09 15:10:56'),
(13, 'Maryam Beasley', 'cijitekove@yahoo.com', 'Doloribus ', 'Female', 'Veritatis ex aspernatur do sit, nesciunt, debitis commodi delectus, ipsa, voluptatem maiores.', '+276-52-3740248', '2017-05-10', 948, 2, 'Pending', '2017-05-09 15:10:40', '2017-05-09 15:10:40'),
(12, 'Sharon Bryant', 'liwu@hotmail.com', 'Neque est ', 'Female', 'Do quidem quis amet, non iure in sed maiores totam nostrud mollitia molestias laboriosam, sit Nam atque nostrud laboris sapiente.', '+715-34-7956620', '2017-05-10', 948, 1, 'Pending', '2017-05-09 15:10:11', '2017-05-09 15:10:11'),
(9, 'Lacey Guzman', 'pale@gmail.com', '34', 'Female', 'Incidunt, sint proident, duis labore ad dolor labore qui aliquip ad quo esse aliquam doloribus quis.', '+514-44-4403698', '2017-05-30', 948, 3, 'Pending', '2017-05-09 13:31:12', '2017-05-09 13:31:12'),
(10, 'Lillith Blair', 'jexudyj@yahoo.com', '32', 'Female', 'Purpose', '+914-56-8759991', '2017-05-30', 950, 3, 'Pending', '2017-05-09 14:53:03', '2017-05-09 14:53:03'),
(11, 'Dolan Mason', 'vydic@hotmail.com', 'In dolores', 'Female', 'Pariatur? Illo nostrum et sed et enim ut lorem duis quia expedita recusandae. Doloribus suscipit.', '+816-87-8641739', '2017-05-10', 950, 1, 'Pending', '2017-05-09 15:09:05', '2017-05-09 15:09:05'),
(16, 'Lillian Cannon', 'xucyhanyfe@yahoo.com', 'Ut veniam ', 'Female', 'Molestiae dolor sapiente dolor laudantium, aperiam sed adipisci Nam nisi ipsum, enim et impedit, repudiandae fugiat, quibusdam dicta quam enim.', '+527-52-4584994', '2009-12-21', 948, 4, 'Pending', '2017-05-09 16:16:51', '2017-05-09 16:16:51'),
(17, 'Maxine Pate', 'mibax@hotmail.com', 'Eum rem vo', 'Female', 'Aliquid dolor tenetur necessitatibus dolore veniam, excepteur earum consequat. In facere ipsum quidem qui consequatur.', '+413-88-1919887', '2002-01-17', 948, 3, 'Pending', '2017-05-09 16:23:15', '2017-05-09 16:23:15'),
(18, 'Carolyn Washington', 'mapoxu@hotmail.com', 'Mollitia m', 'Female', 'Aliquip ut error sed ipsa, consectetur, atque amet, et sequi fugit, aut aut sunt excepturi qui ut et fugit, possimus.', '+928-85-3407737', '1981-04-21', 948, 1, 'Pending', '2017-05-09 16:27:19', '2017-05-09 16:27:19'),
(19, 'Lois Chan', 'hyvifotux@hotmail.com', 'Quis eaque', 'Female', 'Qui omnis recusandae. Incididunt fugiat in qui animi, excepteur et placeat, sunt.', '+775-41-6137331', '2017-05-25', 948, 3, 'Pending', '2017-05-09 16:30:01', '2017-05-09 16:30:01'),
(20, 'Henry Terrell', 'puvycu@hotmail.com', '23', 'Female', 'Nulla est cupiditate quisquam ea mollit aut qui placeat, sint.', '+537-93-9423820', '2017-05-17', 951, 2, 'Pending', '2017-05-09 16:33:55', '2017-05-09 16:33:55'),
(21, 'Gurpreet Singh', 'gurpreet2501@gmail.com', '12', 'Female', '', '9872687345', '2017-05-17', 951, 1, 'Pending', '2017-05-09 20:24:38', '2017-05-09 20:24:38');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `time_slots`
--

CREATE TABLE `time_slots` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `time_slots`
--

INSERT INTO `time_slots` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, '10AM to 12PM', '2017-05-09 10:59:22', '0000-00-00 00:00:00'),
(2, '12PM to 2PM', '2017-05-09 10:59:02', '0000-00-00 00:00:00'),
(3, '2PM to 4PM', '2017-05-09 10:59:43', '0000-00-00 00:00:00'),
(4, '4PM to 6PM', '2017-05-09 10:59:52', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role` enum('employee','admin') COLLATE utf8_bin NOT NULL DEFAULT 'employee',
  `full_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `phone_number` varchar(255) COLLATE utf8_bin NOT NULL,
  `added_by` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) COLLATE utf8_bin NOT NULL,
  `block` varchar(255) COLLATE utf8_bin NOT NULL,
  `room_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_of_birth` date NOT NULL,
  `department` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `role`, `full_name`, `phone_number`, `added_by`, `designation`, `block`, `room_no`, `date_of_birth`, `department`) VALUES
(2, 'admin', '$P$B29G7xK82yzBAKSAITWDKi1AhJnKYN0', 'admin@123.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2017-05-09 16:44:15', '2015-07-16 10:50:30', '2017-05-09 05:44:15', 'admin', 'MD', '', 0, '', '', '', '0000-00-00', '0'),
(948, 'xubisumu', '$P$BJQ4wZOE1xr3RO5hY73QVLDneLr76W/', 'podexidil@yahoo.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2017-05-09 15:11:50', '0000-00-00 00:00:00', '2017-05-09 04:18:56', 'employee', 'Ulla Summers', '+454-35-7317928', 0, 'Accusantium eum voluptate esse similique voluptatem Quidem commodo maxime consequatur Dolores ad exercitationem non accusantium dignissimos sit obcaecati', 'U', '6', '1970-01-01', 'Food and Civil Supp.'),
(950, 'topyxy', '$P$B0wtqlmmG06EbMgCAA851YYUGw0vwR/', 'cehude@hotmail.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2017-05-09 14:52:15', '0000-00-00 00:00:00', '2017-05-09 03:52:15', 'employee', 'Magee Cotton', '+859-46-5549163', 0, 'Commodi ea omnis minima laborum Cumque id velit', 'F', '12', '2017-05-31', 'Food and Civil Supp.'),
(951, 'haworagiq', '$P$BTTJw0D4XvXSFSSD0W28Vb68Y8Y3Zu1', 'wolusaw@hotmail.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2017-05-09 16:44:31', '0000-00-00 00:00:00', '2017-05-09 05:44:31', 'employee', 'Keaton Phillips', '+168-81-6838824', 0, 'DC', 'T', '17', '2017-05-31', 'Fishing');

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `phone` int(20) NOT NULL,
  `street_address` varchar(800) CHARACTER SET utf8 NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `post_code` int(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `name`, `phone`, `street_address`, `city`, `country`, `post_code`, `user_id`, `flag`) VALUES
(1, 'Gurpreet Singh', 2541, 'locamo street', 'New Jersey', 'New Castle', 147001, 8, 1),
(2, 'test', 4535353, 'New address', 'lmp', 'Finland', 1687744, 2, 1),
(3, 'Yask ', 84786, 'mjdgajd', 'Pta', 'Indaia', 75666, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`id`, `user_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10),
(11, 22),
(12, 23),
(13, 24),
(14, 25),
(15, 26),
(16, 27),
(17, 28),
(18, 29),
(19, 30),
(20, 32),
(21, 34),
(22, 35),
(23, 36),
(24, 37),
(25, 38),
(26, 39),
(27, 40),
(28, 41),
(29, 42),
(30, 43),
(31, 44),
(32, 45),
(33, 46),
(34, 47),
(35, 48),
(36, 49),
(37, 50),
(38, 54),
(39, 56),
(40, 57),
(41, 58),
(42, 60),
(43, 61),
(44, 64),
(45, 68),
(46, 173),
(47, 217),
(48, 298),
(49, 324),
(50, 325),
(51, 335),
(52, 336),
(53, 337),
(54, 338),
(55, 366),
(56, 369),
(57, 370),
(58, 371),
(59, 375),
(60, 377),
(61, 378),
(62, 383),
(63, 388),
(64, 389),
(65, 391),
(66, 393),
(67, 399),
(68, 400),
(69, 402),
(70, 403),
(71, 415),
(72, 416),
(73, 417),
(74, 425),
(75, 426),
(76, 429),
(77, 430),
(78, 432),
(79, 434),
(80, 436),
(81, 437),
(82, 439),
(83, 446),
(84, 454),
(85, 457),
(86, 458),
(87, 460),
(88, 461),
(89, 462),
(90, 463),
(91, 466),
(92, 467),
(93, 468),
(94, 469),
(95, 470),
(96, 473),
(97, 474),
(98, 475),
(99, 476),
(100, 477),
(101, 479),
(102, 480),
(103, 481),
(104, 482),
(105, 483),
(106, 486),
(107, 487),
(108, 488),
(109, 489),
(110, 490),
(111, 491),
(112, 492),
(113, 493),
(114, 495),
(115, 496),
(116, 497),
(117, 498),
(118, 499),
(119, 500),
(120, 501),
(121, 502),
(122, 503),
(123, 504),
(124, 505),
(125, 506),
(126, 509),
(127, 510),
(128, 511),
(129, 512),
(130, 514),
(131, 516),
(132, 517),
(133, 518),
(134, 519),
(135, 520),
(136, 521),
(137, 522),
(138, 523),
(139, 524),
(140, 525),
(141, 526),
(142, 528),
(143, 529),
(144, 530),
(145, 532),
(146, 533),
(147, 534),
(148, 535),
(149, 536),
(150, 537),
(151, 538),
(152, 539),
(153, 540),
(154, 541),
(155, 542),
(156, 543),
(157, 544),
(158, 545),
(159, 546),
(160, 547),
(161, 548),
(162, 549),
(163, 550),
(164, 551),
(165, 552),
(166, 554),
(167, 557),
(168, 558),
(169, 559),
(170, 560),
(171, 561),
(172, 563),
(173, 564),
(174, 567),
(175, 568),
(176, 575),
(177, 576),
(178, 578),
(179, 579),
(180, 580),
(181, 582),
(182, 590),
(183, 591),
(184, 595),
(185, 603),
(186, 604),
(187, 605),
(188, 607),
(189, 609),
(190, 610),
(191, 611),
(192, 612),
(193, 613),
(194, 616),
(195, 617),
(196, 618),
(197, 619),
(198, 621),
(199, 624),
(200, 626),
(201, 627),
(202, 630),
(203, 631),
(204, 632),
(205, 633),
(206, 635),
(207, 638),
(208, 639),
(209, 640),
(210, 641),
(211, 642),
(212, 643),
(213, 646),
(214, 647),
(215, 649),
(216, 651),
(217, 655),
(218, 657),
(219, 658),
(220, 660),
(221, 732),
(222, 745),
(223, 748),
(224, 756),
(225, 765),
(226, 767),
(227, 771),
(228, 773),
(229, 778),
(230, 780),
(231, 784),
(232, 791),
(233, 793),
(234, 798),
(235, 800),
(236, 801),
(237, 803),
(238, 808),
(239, 821),
(240, 823),
(241, 824),
(242, 833),
(243, 838),
(244, 839),
(245, 840),
(246, 841),
(247, 846),
(248, 847),
(249, 849),
(250, 853),
(251, 856),
(252, 863),
(253, 869),
(254, 870),
(255, 871),
(256, 872),
(257, 878),
(258, 879),
(259, 892),
(260, 893),
(261, 900),
(262, 901),
(263, 908),
(264, 909),
(265, 910),
(266, 916),
(267, 926),
(268, 927),
(269, 936),
(270, 937),
(271, 940),
(272, 943);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time_slots`
--
ALTER TABLE `time_slots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_autologin`
--
ALTER TABLE `user_autologin`
  ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `time_slots`
--
ALTER TABLE `time_slots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=952;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=273;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
