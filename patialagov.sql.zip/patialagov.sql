--
-- Database: `patialagov`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `age` varchar(10) NOT NULL,
  `sex` enum('Male','Female','','') NOT NULL DEFAULT 'Male',
  `subject` varchar(255) NOT NULL,
  `meeting_purpose` longtext NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `employee_id` int(11) NOT NULL,
  `time_slot` int(11) NOT NULL,
  `booking_status` enum('Pending','Accepted','Canceled','') NOT NULL DEFAULT 'Pending',
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `email`, `age`, `sex`, `subject`, `meeting_purpose`, `phone_no`, `date`, `employee_id`, `time_slot`, `booking_status`, `user_id`, `created_at`, `updated_at`) VALUES
(53, 'Test Customer', 'testing@gmail.com', '52', 'Female', 'Test Passed', 'TEst', '98765346367', '2017-05-11', 963, 12, 'Accepted', 965, '2017-05-11 15:27:05', '2017-05-11 15:27:05'),
(54, 'Test Customer', 'testing@gmail.com', '52', 'Female', 'sds', 'sds', '98765346367', '2017-05-11', 963, 5, 'Pending', 965, '2017-05-11 15:28:01', '2017-05-11 15:28:01'),
(55, 'Test Customer', 'testing@gmail.com', '52', 'Female', 'asd', 'asdas', '98765346367', '2017-05-11', 963, 21, 'Pending', 965, '2017-05-11 15:29:49', '2017-05-11 15:29:49'),
(57, 'Test Customer', 'testing@gmail.com', '52', 'Female', 'Test', 'Arsh book', '98765346367', '2017-05-11', 964, 5, 'Accepted', 965, '2017-05-11 16:40:44', '2017-05-11 16:40:44'),
(58, 'Test Customer', 'testing@gmail.com', '52', 'Female', 'edfr', 'frf', '98765346367', '2017-05-21', 964, 21, 'Pending', 965, '2017-05-11 16:42:05', '2017-05-11 16:42:05');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `time_slots`
--

CREATE TABLE `time_slots` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `time_slots`
--

INSERT INTO `time_slots` (`id`, `name`, `created_at`, `updated_at`) VALUES
(5, '10 AM to 10:15 AM', '2017-05-11 10:39:47', '0000-00-00 00:00:00'),
(6, '10:15 AM to 10:30 AM', '2017-05-11 10:40:11', '0000-00-00 00:00:00'),
(7, '10:30 AM to 10:45 AM', '2017-05-11 10:40:26', '0000-00-00 00:00:00'),
(8, '10:45 AM to 11:00 AM', '2017-05-11 10:40:53', '0000-00-00 00:00:00'),
(9, '11:00 AM to 11:15 AM', '2017-05-11 10:41:07', '0000-00-00 00:00:00'),
(10, '11:15 AM to 11:30 AM', '2017-05-11 10:41:23', '0000-00-00 00:00:00'),
(11, '11:30 AM to 11:45 AM', '2017-05-11 10:41:41', '0000-00-00 00:00:00'),
(12, '11:45 AM to 12:00 PM', '2017-05-11 10:41:51', '0000-00-00 00:00:00'),
(13, '12:00 PM to 12:15 PM', '2017-05-11 10:42:11', '0000-00-00 00:00:00'),
(14, '12:15 PM to 12:30 PM', '2017-05-11 10:42:29', '0000-00-00 00:00:00'),
(15, '12:30 PM to 12:45 PM', '2017-05-11 10:42:42', '0000-00-00 00:00:00'),
(16, '12:45 PM to 01:00 PM', '2017-05-11 10:42:51', '0000-00-00 00:00:00'),
(17, '01:00 PM to 01:15 PM', '2017-05-11 10:43:09', '0000-00-00 00:00:00'),
(18, '01:15 PM to 01:30 PM', '2017-05-11 10:43:39', '0000-00-00 00:00:00'),
(19, '01:30 PM to 01:45 PM', '2017-05-11 10:43:53', '0000-00-00 00:00:00'),
(20, '01:45 PM to 02:00 PM', '2017-05-11 10:44:26', '0000-00-00 00:00:00'),
(21, '02:00 PM to 02:15 PM', '2017-05-11 10:44:37', '0000-00-00 00:00:00'),
(22, ' 02:15 PM to 02:30 PM', '2017-05-11 10:45:04', '0000-00-00 00:00:00'),
(23, ' 02:30 PM to  02:45 PM', '2017-05-11 10:45:21', '0000-00-00 00:00:00'),
(24, '02:45 PM to 03:00 PM', '2017-05-11 10:45:43', '0000-00-00 00:00:00'),
(25, '03:00 PM to 03:15 PM', '2017-05-11 10:46:12', '0000-00-00 00:00:00'),
(26, '03:15 PM to 03:30 PM', '2017-05-11 10:46:28', '0000-00-00 00:00:00'),
(27, '03:30 PM to 03:45 PM', '2017-05-11 10:46:36', '0000-00-00 00:00:00'),
(28, '03:45 PM to 04:00 PM', '2017-05-11 10:47:07', '0000-00-00 00:00:00'),
(29, '04:00 PM to 04:15 PM', '2017-05-11 10:47:27', '0000-00-00 00:00:00'),
(30, '04:15 PM to 04:30 PM', '2017-05-11 10:47:41', '0000-00-00 00:00:00'),
(31, '04:30 PM to 04:45 PM', '2017-05-11 10:47:52', '0000-00-00 00:00:00'),
(32, '04:45 PM to 05:00 PM', '2017-05-11 10:48:02', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `profile_pic` varchar(255) COLLATE utf8_bin NOT NULL,
  `sex` varchar(50) COLLATE utf8_bin NOT NULL,
  `age` varchar(10) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role` enum('employee','admin','user') COLLATE utf8_bin NOT NULL DEFAULT 'employee',
  `full_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `phone_number` varchar(255) COLLATE utf8_bin NOT NULL,
  `added_by` int(10) UNSIGNED NOT NULL,
  `designation` varchar(255) COLLATE utf8_bin NOT NULL,
  `block` varchar(255) COLLATE utf8_bin NOT NULL,
  `room_no` varchar(255) COLLATE utf8_bin NOT NULL,
  `date_of_birth` date NOT NULL,
  `department` varchar(255) COLLATE utf8_bin NOT NULL,
  `verified` tinyint(1) NOT NULL,
  `otp` varchar(12) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `profile_pic`, `sex`, `age`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `role`, `full_name`, `phone_number`, `added_by`, `designation`, `block`, `room_no`, `date_of_birth`, `department`, `verified`, `otp`) VALUES
(981, 'admin', '$2y$10$x2iFODS1cRCMXitHtswVCeOtRuCAdLwWhe28R3HE9lUIxPK3BaufG', 'dozuwyriwy@yahoo.com', '', 'Female', 'Vitae sunt', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2017-05-12 15:25:09', '2017-05-12 12:49:55', '2017-05-12 09:55:09', 'admin', 'Paula Fox', '+646-40-4085053', 0, '', '', '', '0000-00-00', '', 0, 'JxYzkIa'),
(998, 'arsh', '$P$BPsLk7OoKZIJkVPWffvCEjYZ7hHBCn.', 'arshdeep79@gmail.com', '', 'Male', '28', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '0000-00-00 00:00:00', '2017-05-12 14:52:07', '2017-05-12 09:22:50', 'user', 'Arshdeep Giri', '919041368726', 0, '', '', '', '0000-00-00', '', 1, '279403'),
(1000, 'gurpreet2501', '$P$Bdr3.FeTSBevcQm/E6PQUBrcyIRKiq.', 'gps@gmail.com', '', 'Male', '30', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '0000-00-00 00:00:00', '2017-05-12 15:01:10', '2017-05-12 09:31:31', 'user', 'Gurpreet Singh', '919814158141', 0, '', '', '', '0000-00-00', '', 1, '791085'),
(1001, 'ryrorurini', '$P$Bv6qevWqel2kNOg5bRY1I6UFTCvPcK0', 'boqocuxe@yahoo.com', '', 'Female', 'Sed ut qui', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2017-05-12 15:25:20', '2017-05-12 15:02:00', '2017-05-12 09:55:20', 'user', 'Kylan Bentley', '9814158141', 0, '', '', '', '0000-00-00', '', 0, '483107');

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_autologin`
--

INSERT INTO `user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('d1caabbdbfe5638802a15dd64bdafc4c', 959, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36', '127.0.0.1', '2017-05-11 08:50:45'),
('ec4d7518114f1a82141902180f828804', 964, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', '127.0.0.1', '2017-05-11 11:14:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) CHARACTER SET utf8 NOT NULL,
  `phone` int(20) NOT NULL,
  `street_address` varchar(800) CHARACTER SET utf8 NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `post_code` int(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`id`, `user_id`) VALUES
(1, 965),
(2, 966),
(3, 967),
(4, 968),
(5, 969),
(6, 970),
(7, 971),
(8, 972),
(9, 973),
(10, 974),
(11, 975),
(12, 976),
(13, 977),
(14, 978),
(15, 979),
(16, 980),
(17, 981),
(18, 982),
(19, 983),
(20, 984),
(21, 985),
(22, 986),
(23, 987),
(24, 988),
(25, 989),
(26, 990),
(27, 991),
(28, 992),
(29, 993),
(30, 994),
(31, 995),
(32, 996),
(33, 997),
(34, 998),
(35, 999),
(36, 1000),
(37, 1001);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `time_slots`
--
ALTER TABLE `time_slots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_autologin`
--
ALTER TABLE `user_autologin`
  ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `time_slots`
--
ALTER TABLE `time_slots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;
--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
