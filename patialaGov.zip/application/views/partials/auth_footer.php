<div class="spacer-100"></div>
<div class="row">
	<div class="col-xs-12">
		<div class="col-xs-2"><a href="#"><img src="<?=base_url()?>/images/cashless.jpg" class="zoom-in" /></div></a>
		<div class="col-xs-2"><a href="#"><img src="<?=base_url()?>/images/ceo.jpg" class="zoom-in" /></div></a>
		<div class="col-xs-2"><a href="#"><img src="<?=base_url()?>/images/sideabar-ad.jpg" class="zoom-in" /></div></a>
		<div class="col-xs-2"><a href="#"><img src="<?=base_url()?>/images/di.jpg" class="zoom-in" /></div></a>
		<div class="col-xs-2"><a href="#"><img src="<?=base_url()?>/images/fardimage.jpg" class="zoom-in" /></div></a>
		<div class="col-xs-2"><a href="#"><img src="<?=base_url()?>/images/download.jpg" class="zoom-in" /></div></a>
	</div>
</div>	
<div class="row">
	<div class="col-xs-12">
		<div class="footer">
			Copyright &copy; 2017
		</div>
	</div>
</div>
</div> <!-- container ends -->
 <script src="<?=base_url('assets/js/jquery.js')?>"></script>
 <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.14.0/jquery.validate.min.js"></script>
 <script> jQuery("form").validate(); </script>
 </body>
</html
				
