<ul class="nav navbar-nav side-nav">
    <li class="active">
      <a href='<?php echo site_url('/user/bookings')?>'>Your Bookings</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/user/update_password')?>'>Update Password</a> 
    </li>
</ul>