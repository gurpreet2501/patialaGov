<ul class="nav navbar-nav side-nav">
    <li class="active">
      <a href='<?php echo site_url('/employee/bookings')?>'>Bookings</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/employee/employeeBookings')?>'>Send Booking Feedback</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/employee/bookingFeedbacks')?>'>Feedbacks</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/employee/update_password')?>'>Update Password</a> 
    </li>
</ul>