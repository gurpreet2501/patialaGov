<ul class="nav navbar-nav side-nav">
    <li class="active">
      <a href='<?php echo site_url('/admin/users')?>'>Add Employee</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/admin/bookings')?>'>Current Bookings</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/admin/acceptedBookings')?>'>Bookings Accepted By Employee</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/admin/bookingsCount')?>'>Todays Booking Count of Employees</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/admin/feedbacks')?>'>Employee Feedbacks</a> 
    </li>
    <li class="active">
      <a href='<?php echo site_url('/admin/update_password')?>'>Update Password</a> 
    </li>
</ul>