<?php $this->load->view('partials/header'); ?>
<div class="content">
	<div class="container">
		<div class="row">
			<div class="col-xs-3">
				<?php $this->load->view('partials/leftSidebar'); ?>
			</div>
			<!-- Content area starts -->
						<div class="col-xs-6">
					<div class="main">
					<br/>
							<!-- Slider starts -->
								<div class="slider">
									<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
									  <div class="carousel-inner" role="listbox">
									    <div class="item active">
									      <img src="<?=base_url()?>/images/slider-1.jpg" class='slider-images' alt="">
									      <div class="carousel-caption">
									        
									      </div>
									    </div>
									    <div class="item">
									      <img src="<?=base_url()?>/images/slider-3.jpg" class='slider-images' alt="">
									      <div class="carousel-caption">
									        
									      </div>
									    </div>
									    <div class="item">
									      <img src="<?=base_url()?>/images/slider-2.jpg" class='slider-images' alt="">
									      <div class="carousel-caption">
									        
									      </div>
									    </div>
									    <div class="item">
									      <img src="<?=base_url()?>/images/Fountain.JPG" class='slider-images' alt="">
									      <div class="carousel-caption">
									        
									      </div>
									    </div>
									    <div class="item">
									      <img src="<?=base_url()?>/images/Dukhniwaran.JPG" class='slider-images' alt="">
									      <div class="carousel-caption">
									        
									      </div>
									    </div>
									  </div>
									</div>
								</div>
								<!-- Slider ends -->
								<hr/>
								<p>
									<img src="<?=base_url()?>/images/Digital-Locker_logo.jpg" width="70%" class="img-pad" align="left" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut  ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.			
								</p>
								<p>
								ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint 
								</p>
								<br/>
								<p>ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint 
								ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint </p>
								<br/>
								<p>ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint </p>
								<br/>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut  ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.			</p>
								<br/>

					</div> <!-- main block ends -->			
			</div>
			<!-- Content area starts -->
		  <div class="col-xs-3 text-center">
				<?php $this->load->view('partials/rightSidebar');?>
			</div> <!-- right side bar ends -->
		</div>
	</div>
</div>
<?php $this->load->view('partials/footer'); ?>