<?php $this->load->view('partials/header');?>
<div class="container">
 <div class="row">
   <div class="col-xs-2"></div>
   <div class="col-xs-10">
     <h2>Confirmation</h2>
   </div>
  </div>
  <div class="row">  
   <div class="col-xs-2"></div>
   <div class="col-xs-10">
      <?=$message;?>
   </div>
 </div>
</div>
