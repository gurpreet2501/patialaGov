<h3>Patiala Polling Stations</h3>
<ul>
<a href="<?=base_url('pdfs/109-Nabha.pdf')?>"><li>109 Nabha</li></a>
<a href="<?=base_url('pdfs/110-Patiala.pdf')?>"><li>110 Patiala Rural</li></a>
<a href="<?=base_url('pdfs/111-Rajpura.pdf')?>"><li>111 Rajpura</li></a>
<a href="<?=base_url('pdfs/113-Ghanour.pdf')?>"><li>113 Ghanaur</li></a>
<a href="<?=base_url('pdfs/114-Sanaur.pdf')?>"><li>114 Sanaur</li></a>
<a href="<?=base_url('pdfs/115-Patiala.pdf')?>"><li>115 Patiala</li></a>
<a href="<?=base_url('pdfs/116-Samana.pdf')?>"><li>116 Samana</li></a>
<a href="<?=base_url('pdfs/117-Shutrana.pdf')?>"><li>117 Shutrana</li></a>
<a href="<?=base_url('pdfs/Proposed Polling Station Summary.pdf')?>"><li>Proposed Polling Station Summary</li></a>
</ul>


