<blockquote>
		
		<!--  Page Contents Starts Here -->	

<h3>Right To Information Act</h3>
<ul type="square">
<li> 
<a href="<?=base_url('pdfs/rti_InfoEng.pdf')?>">General Information in English</a></li><a href="<?=base_url('pdfs/rti_InfoEng.pdf')?>">
</a><li><a href="<?=base_url('pdfs/rti_InfoEng.pdf')?>">
</a><a href="<?=base_url('pdfs/rti.pdf')?>"> RTI Application Form</a></li><a href="<?=base_url('pdfs/rti.pdf')?>">
</a><li><a href="<?=base_url('pdfs/rti.pdf')?>">
</a><a href="<?=base_url('pdfs/rti_formD.pdf')?>"> RTI Form D</a></li><a href="<?=base_url('pdfs/rti_formD.pdf')?>">
</a><li><a href="<?=base_url('pdfs/rti_formD.pdf')?>">
</a><a href="<?=base_url('pdfs/rti_formE.pdf')?>"> RTI Form E</a></li><a href="<?=base_url('pdfs/rti_formE.pdf')?>">
</a><li><a href="<?=base_url('pdfs/rti_formE.pdf')?>">
</a><a href="http://righttoinformation.gov.in/"> Right to Information Act</a></li><a href="http://righttoinformation.gov.in/">
</a><li><a href="http://righttoinformation.gov.in/"> 
</a><a href="http://righttoinformation.gov.in/RTI-<?=base_url('pdfs/Act.pdf')?>">Download Right To Information Act</a></li>
<a href="http://righttoinformation.gov.in/RTI-<?=base_url('pdfs/Act.pdf')?>">
</a><li><a href="http://righttoinformation.gov.in/RTI-<?=base_url('pdfs/Act.pdf')?>"></a><a href="<?=base_url('pdfs/Comm.pdf')?>">Manual For Commissioner Office, Patiala Divison </a></li>
<li>
<a href="<?=base_url('pdfs/DCOffice.pdf')?>">Manual For Deputy Commissioner Office, Patiala </a></li>



</ul>
		</blockquote>