<div id="DC">
<h2>Deputy Commissioner Patiala</h2>
<table>
<tbody><tr>
<td>Name : </td>
<td>Kumar Amit</td>
</tr>
<tr>
<td>IAS Batch : </td>
<td>2010</td>
</tr>
</tbody></table>

<img src="images/dc.JPG" width="200" style="padding:10px" align="left">
<h4>Message of Deputy Commissioner</h4>
<p>These days, Internet has become the best platform in sphere of information Technology where anyone can share information, experiences, thoughts and knowledge.National Informatics Centre Patiala has done excellent work in launching the website which highlights information regarding various aspects of the District i.e Historical, Statistical, Cultural, Administrative Setup and other relevant information for the benefit of general public. I commend NIC Patiala for its efforts in designing, developing, hosting and continual modification of this website on NIC's Server.</p>


<p>It will be our endeavor to interact closely with the common man and this web site serves as a medium through which we invite suggestions from general public in an effort towards making the administration more responsive and efficient. I hope the information of the website would be beneficial to the end-user. </p>	

</div>