<hr/>
<img src="<?=base_url('images/tehsil.jpg')?>" class="img-fit-container" />
<hr/>
<img src="<?=base_url('images/district.jpg')?>" class="img-fit-container" />