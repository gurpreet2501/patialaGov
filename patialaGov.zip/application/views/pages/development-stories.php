<blockquote>
			<ol type="1">

			<li><p align="justify"><b>P</b>UDA constructed <b><i><u>Mini Secretariat</u></i></b> at the Central Jail Road with the purpose that people could get their works relating to different offices done from one place only and Phulkian Enclave residential colony is also developed by PUDA</p></li>
			<li><p align="justify"><b>S</b>ewerage Treatment Plant was constructed at Urban Estate, Patiala.</p></li>
			<li><p align="justify"><b>U</b>nder the Integrated Township Scheme of Patiala Development Authority, a modern residential colony and an I.T. Park are being developed at Baran on the Sirhind Road.</p></li>
			<li><p align="justify"><b>A</b> new Judicial Court Complex has been constructed.</p></li>
			<li><p align="justify"><b>A</b> flyover has been  constructed at 21 No.  Railway Crossing.</p></li>
			<li><p align="justify"><b>F</b>ollowing <b>roads</b> have been strengthened and broadened :-</p></li>
				<ol type="a">
					<li><p align="justify">Patiala to Pehowa.</p></li>
					<li><p align="justify">Patiala to Goohla.</p></li>
					<li><p align="justify">Patiala to Sangrur.</p></li>
					<li><p align="justify">Patiala to Samana – Goohla.</p></li>
					<li><p align="justify">Link Roads around Patiala.</p></li>
				</ol>

			<li><p align="justify"><b>A</b> bypass has been constructed at Patran for the convenience of about 150 villages of Patiala and Sangrur districts.</p></li>
			<li><p align="justify"><b>Four laning</b> is being done at:-</p></li>
				<ol type="a">
					<li><p align="justify">Patiala-Sangrur Road upto Bhakhra Bridge.</p></li>
					<li><p align="justify">Patiala-Sirhind Road upto Baran.</p></li>
				</ol>
			<li><p align="justify"><b>A</b>n indoor Stadium has been constructed to augment infrastructure of sports at the Polo Ground.</p></li>
			<li><p align="justify"><b>F</b>or beautification of the Patiala city, Sodium Lights have been installed on the Mall Road, The Lower Mall, Mohindra College, Chhoti Nadi and Factory Area.</p></li>
			<li><p align="justify"><b>T</b>o make Patiala a real <b><i>"City of Gardens",</i></b> many parks have been laid.</p></li>
			<li><p align="justify">A ‘<b>Modern SUWIDHA Centre</b>’ has been set up for providing single window facility for various kinds of services viz.Arms License, Driving License, Registration of vehicles, Affidavit Attestation, certificates issued by M.A. Branch, Passport Services and Marriage Registration etc. </p></li>
						</ol>

	
		
		</blockquote>