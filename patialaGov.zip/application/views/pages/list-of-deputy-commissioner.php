<table>
<tbody><tr>
<td>S.No.</td>
<td>Name</td>
<td>Date of Joining</td>
<td>Date of Relieving</td>
</tr>
<tr>
<td>1.</td>
<td>Mr. S. S. Sodhi IAS</td>
<td>1954</td>
<td>30.05.1957</td>
</tr>
<tr>
<td>2.</td>
<td>Mr. D.S. Bhambri IAS</td>
<td>31.07.1957</td>
<td>25.11.1957 </td>
</tr>
<tr>
<td>3.</td>
<td>Mr.Sampuran Singh IAS</td>
<td>04.12.1957</td>
<td>08.03.1958</td>
</tr>
<tr>
<td>4.</td>
<td>Mr. R. S. Bhatnagar IAS</td>
<td>13.03.1958</td>
<td>02.08.1958</td>
</tr>
<tr>
<td>5.</td>
<td>Mr.Sampuran Singh IAS</td>
<td>05.08.1958</td>
<td>22.12.1958</td>
</tr>
<tr>
<td>6.</td>
<td>Mr. S. N. Vasudev IAS</td>
<td>31.01.1959</td>
<td>24.02.1960</td>
</tr>
<tr>
<td>7.</td>
<td>Mr. R. S. Bhatnagar IAS </td>
<td>25.02.1960</td>
<td>08.04.1960</td>
</tr>
<tr>
<td>8.</td>
<td>Mr. P. N. Bhalla IAS</td>
<td>12.04.1960</td>
<td>09.03.1961</td>
</tr>
<tr>
<td>9.</td>
<td>Mr. S. N. Bhanot IAS</td>
<td>10.03.1961</td>
<td>22.03.1963</td>
</tr>
<tr>
<td>10.</td>
<td>Mr. Sundar Singh IAS</td>
<td>22.03.1963</td>
<td>16.01.1967</td>
</tr>
<tr>
<td>11.</td>
<td>Mr. P. C. Behal PCS</td>
<td>17.01.1967</td>
<td>24.07.1967</td>
</tr>
<tr>
<td>12.</td>
<td>Mr. S. L. Kapoor IAS</td>
<td>24.07.1967</td>
<td>25.07.1968</td>
</tr>
<tr>
<td>13.</td>
<td>Mr. Ajit Singh Chattha IAS</td>
<td>25.07.1968</td>
<td>04.09.1968</td>
</tr>
<tr>
<td>14.</td>
<td>Mr. S. L. Kapoor IAS</td>
<td>05.09.168</td>
<td>12.05.1970</td>
</tr>
<tr>
<td>15.</td>
<td>Mr. S. S. Boparai IAS</td>
<td>14.05.1970</td>
<td>09.06.1971</td>
</tr>
<tr>
<td>16.</td>
<td>Mr. K. K. Mukherji IAS</td>
<td>10.06.1971</td>
<td>02.08.1971</td>
</tr>
<tr>
<td>17.</td>
<td>Mr. Hardial Singh IAS</td>
<td>11.08.1971</td>
<td>06.06.1972</td>
</tr>
<tr>
<td>18.</td>
<td>Mr. Gurdev Singh Gill IAS</td>
<td>07.06.1972</td>
<td>31.05.1973</td>
</tr>
<tr>
<td>19.</td>
<td>Mr. Darshan Kumar IAS</td>
<td>01.06.1973</td>
<td>18.05.1974</td>
</tr>
<tr>
<td>20.</td>
<td>Mr. Inderjit Singh Bindra IAS</td>
<td>19.05.1974</td>
<td>14.07.1975</td>
</tr>
<tr>
<td>21.</td>
<td>Mr. D.S. Choudhary IAS</td>
<td>14.07.1975</td>
<td>22.04.1977</td>
</tr>
<tr>
<td>22.</td>
<td>Mr. S. S. Dawra IAS</td>
<td>22.04.1977</td>
<td>02.02.1980</td>
</tr>
<tr>
<td>23.</td>
<td>Mr. S. S. Sidhu IAS</td>
<td>12.02.1980</td>
<td>05.03.1980</td>
</tr>
<tr>
<td>24.</td>
<td>Mr. Pritam Singh Bala IAS</td>
<td>10.03.1980</td>
<td>30.09.1981 </td>
</tr>
<tr>
<td>25.</td>
<td>Mr. Karam Singh Raju IAS</td>
<td>02.10.1981</td>
<td>23.06.1982</td>
</tr>
<tr>
<td>26.</td>
<td>Mr. S.P. Singla IAS</td>
<td>23.06.1982</td>
<td>13.06.1984</td>
</tr>
<tr>
<td>27.</td>
<td>Mr. S. K. Sinha IAS</td>
<td>13.09.1984</td>
<td>29.06.1987</td>
</tr>
<tr>
<td>28.</td>
<td>Mr. Bhushan C. Gupta IAS</td>
<td>29.06.1987</td>
<td>05.11.1990</td>
</tr>
<tr>
<td>29.</td>
<td>Mr. Satpal Karkra IAS </td>
<td>06.11.1990</td>
<td>15.05.1992</td>
</tr>
<tr>
<td>30.</td>
<td>Mr. Navreet Singh Kang IAS</td>
<td>18.05.1992</td>
<td>05.05.1993</td>
</tr>
<tr>
<td>31.</td>
<td>Mr.T.C. Gupta IAS</td>
<td>11.05.1993</td>
<td>19.07.1995</td>
</tr>
<tr>
<td>32.</td>
<td>Mr. Jagpal Singh Sandhu IAS</td>
<td>19.07.1995</td>
<td>09.08.1996</td>
</tr>
<tr>
<td>33.</td>
<td>Mr. C. Roul IAS</td>
<td>09.08.1996</td>
<td>02.09.1996</td>
</tr>
<tr>
<td>34.</td>
<td>Mr.Amarjit Singh Sidhu IAS</td>
<td>02.09.1996</td>
<td>31.05.1997</td>
</tr>
<tr>
<td>35.</td>
<td>Mr. Vishwajeet Khanna IAS</td>
<td>01.06.1997</td>
<td>16.12.1998</td>
</tr>
<tr>
<td>36.</td>
<td>Mr.Jasbir Singh Bir IAS</td>
<td>16.12.1998</td>
<td>04.03.2002</td>
</tr>
<tr>
<td>37.</td>
<td>Mr.Tejveer Singh IAS</td>
<td>04.03.2002</td>
<td>10.04.2006</td>
</tr>
<tr>
<td>38.</td>
<td>Mr.R.K.Verma IAS</td>
<td>10.04.2006</td>
<td>11.03.2007</td>
</tr>
<tr>
<td>39.</td>
<td>Mr. D.S. Grewal IAS</td>
<td>12.03.2007</td>
<td>01.09.2008</td>
</tr>
<tr>
<td>40.</td>
<td>Mr.Vikas Garg IAS</td>
<td>01.09.2008</td>
<td>28.01.2009</td>
</tr>
<tr>
<td>41.</td>
<td>Mr Deepinder Singh IAS</td>
<td>28.01.2009</td>
<td>25.02.2010</td>
</tr>
<tr>
<td>42.</td>
<td>Mr. Priyank Bharti IAS</td>
<td>26.02.2010</td>
<td>10.04.2010</td>
</tr>
<tr>
<td>43.</td>
<td>Mr Deepinder Singh IAS</td>
<td>11.04.2010</td>
<td>28.07.2011</td>
</tr>
<tr>
<td>44.</td>
<td>Mr.Vikas Garg IAS</td>
<td>09.08.2011</td>
<td>20.04.2012</td>
</tr>
<tr>
<td>45.</td>
<td>Mr.G.K. Singh IAS</td>
<td>21.04.2012</td>
<td>01.04.2014</td>
</tr>
<tr>
<td>46.</td>
<td>Mr. Priyank Bharti IAS</td>
<td>01.04.2014</td>
<td>29.05.2014</td>
</tr>
<tr>
<td>47.</td>
<td>Mr.Varun Roojam IAS</td>
<td>30.05.2014</td>
<td>02.02.2016</td>
</tr>
<tr>
<td>48.</td>
<td>Mr. Ramvir  IAS</td>
<td>02.02.2016</td>
<td>17.03.2017</td>
</tr>
<tr>
<td>49.</td>
<td>Mr. Kumar Amit IAS</td>
<td>17.03.2017</td>
<td></td>
</tr>
</tbody></table>