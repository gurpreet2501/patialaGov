<h3>Patiala Polling Stations</h3>
<table id="PageDetails" border="1" cellspacing="0" cellpadding="0" width="80%" align="center">
  <tbody>
  <tr>
    <td bgcolor="blue" width="10%">
      <p align="center"><b><font color="cornsilk" face="Arial">AC NO. 
    </font></b></p></td>
    <td bgcolor="blue" width="50%">
      <p align="center"><b><font color="cornsilk" face="Arial">Assembly Constituency 
      Name </font></b></p></td>
    <td bgcolor="blue" width="30%">
      <p align="center"><b><font color="cornsilk" face="Arial">Type 
  </font></b></p></td></tr>
  
  
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">109 </font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
      <a href="<?=base_url('pdfs/VS2017109.pdf')?>">Nabha</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">SC </font></b></p></td></tr>
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">110 </font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
     <a href="<?=base_url('pdfs/VS2017110.pdf')?>">Patiala 
      Rural</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">Gen </font></b></p></td></tr>
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">111 </font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
     <a href="<?=base_url('pdfs/VS2017111.pdf')?>">Rajpura</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">Gen </font></b></p></td></tr>
  
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">113 </font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
     <a href="<?=base_url('pdfs/VS2017113.pdf')?>">Ghanaur</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">Gen </font></b></p></td></tr>
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">114 </font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
      <a href="<?=base_url('pdfs/VS2017114.pdf')?>">Sanour</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">Gen </font></b></p></td></tr>
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">115</font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
      <a href="<?=base_url('pdfs/VS2017115.pdf')?>">Patiala</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">Gen </font></b></p></td></tr>
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">116 </font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
     <a href="<?=base_url('pdfs/VS2017116.pdf')?>">Samana</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">Gen </font></b></p></td></tr>
  <tr>
    <td bgcolor="cornsilk" width="10%">
      <p align="center"><b><font color="blue" face="Arial">117</font></b></p></td>
    <td bgcolor="cornsilk" width="50%">
      <p align="left"><b><font color="blue" face="Arial">
     <a href="<?=base_url('pdfs/VS2017117.pdf')?>">Shutrana</a></font></b></p></td>
    <td bgcolor="cornsilk" width="30%">
      <p align="center"><b><font color="blue" face="Arial">SC 
  </font></b></p></td></tr></tbody></table>