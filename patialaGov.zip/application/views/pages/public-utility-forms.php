<blockquote>
		
                <span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 

                        <ul>

                          <li><a href="<?=base_url('pdfs/arms_licence.pdf')?>">Application 
                          form for Arm License (Form A)</a> 
                          </li><li><a href="<?=base_url('pdfs/backward_class_certificate.pdf')?>">Backward 
                          Class Certificate</a> 
                          </li><li><a href="<?=base_url('pdfs/birth_death_certificat.pdf')?>">Birth 
                          &amp; Death Certificate</a> 
                          
                          </li><li><a href="<?=base_url('pdfs/certificate_for_scheduled_caste.pdf')?>">Scheduled 
                          Caste Certificate</a> 
                          </li><li><a href="<?=base_url('pdfs/Form-20.pdf')?>">Application 
                          for Registration of a Motor Vehicle (Form 20)</a> 
                          </li><li><a href="<?=base_url('pdfs/form_3_learner_licence.pdf')?>">Application 
                          for Learner’s Licence (Form 3)</a> 
                          </li><li><a href="<?=base_url('pdfs/form_2_renewal_of_learner_licence.pdf')?>">Application 
                          for Renewal of learner’s licence (Form 2)</a> 
                          </li><li><a href="<?=base_url('pdfs/form_32A_dto.pdf')?>">Form 
                          32-A</a> 
                          </li><li><a href="<?=base_url('pdfs/form_4_driving.pdf')?>">Application 
                          for Licence to Drive a Motor Vehicle (Form 4)</a> 
                          </li><li><a href="<?=base_url('pdfs/form_9_renew_lic.pdf')?>">Application 
                          for the Renewal of Driving Licence (Form 9)</a> 
                          </li><li><a href="<?=base_url('pdfs/guidelines_sc_certificate.pdf')?>">Issuance 
                          of B.C./S.C./O.B.C./Residence/Rural Area 
                          Certificate</a> 
                          </li><li><a href="<?=base_url('pdfs/Indira_Awas_Yojna_Form.pdf')?>">Indira 
                          Awas Yojna Form</a> 
                          </li><li><a href="<?=base_url('pdfs/obc_certificate.pdf')?>">OBC 
                          Certificate</a> 
                          </li><li><a href="<?=base_url('pdfs/marriage_certificate_forms.pdf')?>">Application 
                          for Registration of Marriage</a> 
                          </li><li><a href="<?=base_url('pdfs/rail_reservation_form.pdf')?>">Railway 
                          Reservation/Cancellation Requisition Form</a> 
                          </li><li><a href="<?=base_url('pdfs/residence_certificate.pdf')?>">Residence 
                          Certificate</a> 
                          </li><li><a href="<?=base_url('pdfs/sc-proforma1.pdf"')?>>Certificate 
                          for Scheduled Caste</a> 
                          </li><li><a href="<?=base_url('pdfs/rural_area_certi.pdf')?>">Rural 
                          Area Certificate</a> 
                          </li><li><a href="<?=base_url('pdfs/sc-proforma2.pdf')?>">Issue 
                          of Scheduled Caste/Scheduled Tribe/Backward Class 
                          Certificate</a> </li></ul>
                          </span>

			<!--  Page Contents Ends Here -->		
		
		</blockquote>