<div class="content">
<h1>TELEPHONE NUMBERS - DISTRICT PATIALA</h1>
<h2>District Administration</h2>
<center>
<table>
<tbody><tr>
<td>S.No.</td>
<td>Designation</td>
<td>Office No.</td>
<td>Residence No.</td>
</tr>
<tr>
<td>1.</td>
<td>Divisional Commissioner, Patiala </td>
<td>2311324</td>
<td>2212052</td>
</tr>
<tr>
<td>2.</td>
<td>Deputy Commissioner, Patiala </td>
<td>2311300, 2311301</td>
<td>2311302, 2311303, Fax </td>
</tr>
<tr>
<td>3.</td>
<td>ADC(General)</td>
<td>2311304</td>
<td>2311305</td>
</tr>
<tr>
<td>4.</td>
<td>ADC (Development)</td>
<td>2311306</td>
<td>2311307</td>
</tr>
<tr>
<td>5.</td>
<td>Assistant Commissioner (Gen) </td>
<td>2311308</td>
<td>2311309</td>
</tr>
<tr>
<td>6.</td>
<td>Assistant Commissioner (Griev.)  </td>
<td>2311310</td>
<td></td>
</tr>
<tr>
<td>7.</td>
<td>Distt. Transport Officer </td>
<td>2311316</td>
<td></td>
</tr>
<tr>
<td>8.</td>
<td>Distt. Development Panchayat Officer</td>
<td>2311315</td>
<td></td>
</tr>
<tr>
<td>9.</td>
<td>Distt. Revenue Officer  </td>
<td>2311311</td>
<td>2311314</td>
</tr>
<tr>
<td>10.</td>
<td>Distt. Informatics Officer,Patiala</td>
<td>2350997</td>
<td>2209724</td>
</tr>
<tr>
<td>11.</td>
<td>District Small Saving Officer, Patiala</td>
<td>2351400</td>
<td>2303942</td>
</tr>
<tr>
<td>12.</td>
<td>SDM, Patiala</td>
<td>2311319</td>
<td>2311320</td>
</tr>
<tr>
<td>13.</td>
<td>SDM, Samana</td>
<td>220038</td>
<td>221146</td>
</tr>
<tr>
<td>14.</td>
<td>SDM, Nabha </td>
<td>220646</td>
<td>220645</td>
</tr>
<tr>
<td>15.</td>
<td>SDM Rajpura </td>
<td>223000</td>
<td>240240</td>
</tr>
<tr>
<td>16.</td>
<td>SDM, Patran</td>
<td>243610</td>
<td></td>
</tr>
<tr>
<td>17.</td>
<td>Tehsildar, Patiala</td>
<td>2311321</td>
<td></td>
</tr>
<tr>
<td>18.</td>
<td>Tehsildar Nabha</td>
<td>220654</td>
<td>229564</td>
</tr>
<tr>
<td>19.</td>
<td>Tehsildar, Samana</td>
<td>221190</td>
<td>2223528</td>
</tr>
<tr>
<td>20.</td>
<td>Tehsildar, Rajpura</td>
<td>224132</td>
<td>2212052</td>
</tr>
<tr>
<td>21.</td>
<td>Tehsildar, Patran </td>
<td>243403</td>
<td></td>
</tr>
<tr>
<td>22.</td>
<td>Tehsildar, Election</td>
<td>2350779</td>
<td></td>
</tr>
</tbody></table>
<h2>Naib Tehsildars </h2>
<table>
<tbody><tr>
<td>S. No.</td>
<td>Designation</td>
<td>Office No.</td>
</tr>
<tr>
<td>1.</td>
<td>NT Nabha</td>
<td>01765-220654</td>
</tr>
<tr>
<td>2.</td>
<td>NT Rajpura  </td>
<td>01762-224132</td>
</tr>
<tr>
<td>3.</td>
<td>NT Patran</td>
<td>01764-243403</td>
</tr>
<tr>
<td>4.</td>
<td>NT Samana   </td>
<td>01764-221190</td>
</tr>
<tr>
<td>5.</td>
<td>NT Patiala</td>
<td>0175-2311321</td>
</tr>
</tbody></table>
</center>
</div>
<!-- ------------- -->
<h2>District Heads</h2>
<table class="MsoNormalTable">
 
<tbody>
  <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <td >
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span >Designation<o:p></o:p></span></b></p></td>
    <td  valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    
</tr><tr style="mso-yfti-irow: No.">   
    <td  valign="top" width="162">
      
      <p class="MsoNormal"  valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752211147 <o:p></o:p></span></b></p></td>
    
 </tr><tr style="mso-yfti-irow: No.">
<td  valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Director&nbsp;Horticulture,&nbsp;Patiala</span></b></p></td>
    <td  valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752308910<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: No.">   
    <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Director,&nbsp;Sports,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td  valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752212576 <o:p></o:p></span></b></p></td>
   </tr><tr style="mso-yfti-irow: No.">   
    <td  valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Director,&nbsp;District&nbsp;Bureau&nbsp;of&nbsp;Employment Generation&nbsp;&amp;&nbsp;Training,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td  valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752206356 <o:p></o:p></span></b></p></td>
   
  
</tr><tr style="mso-yfti-irow: No.">
  <td  valign="top" width="162">
       <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Treasury&nbsp;Officer,&nbsp;Patiala<o:p></o:p></span></b></p></td>
   
 <td  valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752360404 01752363709<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: No.">
  <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Program&nbsp;Officer,&nbsp;Patiala </span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752362781<o:p></o:p></span></b></p></td>
   
</tr><tr style="mso-yfti-irow: No.">
  <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Welfare&nbsp;Officer,&nbsp;Patiala </span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752370574 <o:p></o:p></span></b></p></td>
   
 </tr><tr style="mso-yfti-irow: No.">
  <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Town&nbsp;Planner&nbsp;Officer,&nbsp;Patiala </span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752211675<o:p></o:p></span></b></p></td>
     
    
</tr><tr style="mso-yfti-irow: No.">   
    <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Controller,&nbsp;Govt.&nbsp;Press,&nbsp;Sirhand Road, Patiala<o:p></o:p></span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752363050 <o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: No.">   
    <td valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Agriculture&nbsp;Officer,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752214774 <o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: No.">    
 <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Dy.&nbsp;Registrar,&nbsp;Cooperative&nbsp;Societies,Patiala<o:p></o:p></span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215808 01752203324</span></b></p></td>

</tr><tr style="mso-yfti-irow: No.">    
 <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Assistant&nbsp;Director&nbsp;Fisheries,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752206461</span></b></p></td>
</tr><tr style="mso-yfti-irow: No.">    
 <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Director&nbsp;Animal&nbsp;Husbandary,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752360160</span></b></p></td>
</tr><tr style="mso-yfti-irow: No.">    
 <td valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Dy.&nbsp;Economic&nbsp;&amp;&nbsp;Statistical&nbsp;Officer,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style=" PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in;  mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752200232</span></b></p></td>
   
     
</tr></tbody></table>

<!-- ----------------- -->
<h2>Zila Parishad BDPO's and CDPO's</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
<tbody>
  <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
   
</tr><tr style="mso-yfti-irow: No.">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Dy.&nbsp;Chief&nbsp;Executive&nbsp;Officer, Zila Parishad, Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752360055<o:p></o:p></span></b></p></td>
    

 </tr><tr style="mso-yfti-irow: No.">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">XEN,&nbsp;Panchayati&nbsp;Raj,&nbsp;Patiala<o:p></o:p></span></b> </p></td>

 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752336188<o:p></o:p></span></b></p></td>
    

</tr><tr style="mso-yfti-irow:No.">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><span class="SpellE"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Executive&nbsp;Engineer,&nbsp;Patiala  </span></b></span>
     <b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <span class="SpellE"></span>  <o:p> </o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752363935<o:p></o:p></span></b></p></td>
   
 </tr><tr style="mso-yfti-irow: No.">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO,  Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752363307<o:p></o:p></span></b></p></td>
   
  
</tr><tr style="mso-yfti-irow: No.">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO, Bhunerheri<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752201156<o:p></o:p></span></b></p></td>
    
 
 </tr><tr style="mso-yfti-irow: No.">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO, Sanour<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752309354<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: No.">
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO, Samana <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764220031<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: No.">  
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO, Patran<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764243033<o:p></o:p></span></b></p></td>
   
 
 </tr><tr style="mso-yfti-irow: No.">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO, Nabha<o:p>&nbsp;</o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01765220317<o:p>&nbsp;</o:p></span></b></p></td>
    
  
</tr><tr style="mso-yfti-irow: No.">
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO, Rajpura<o:p></o:p></span></b></p></td>
   
   <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762224403<o:p></o:p></span></b></p></td>
   
  
</tr><tr style="mso-yfti-irow: No.">    
     <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">BDPO, Ghanour<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762267455<o:p></o:p></span></b></p></td>
   
  
</tr><tr style="mso-yfti-irow: No.">
     <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO(U), Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752302242<o:p></o:p></span></b></p></td>
   
</tr><tr style="mso-yfti-irow: No.">    
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO(R), Patiala
      <span class="SpellE"></span><o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752360270<o:p></o:p></span></b></p></td>
   
  
</tr><tr style="mso-yfti-irow: No.">  
   <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO, Sanour
      <span class="SpellE">  </span><o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752365148
      <o:p></o:p></span></b></p>
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></span></b></p></td>
   
  
 </tr><tr style="mso-yfti-irow: No.">
   <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO, Bhunerheri
      <span class="SpellE"></span><o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752201208<o:p></o:p></span></b></p></td>
    
  
 </tr><tr style="mso-yfti-irow: No.">   
   <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO, Samana <span class="SpellE"></span><o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764224504<o:p></o:p></span></b></p></td>
    
 </tr><tr style="mso-yfti-irow: No.">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO, Nabha
 <span class="SpellE"></span><o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01765224396<o:p></o:p></span></b></p></td>
    
 
</tr><tr style="mso-yfti-irow: No.">   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO, Ghanour 
      <span class="SpellE"></span><o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762238728<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><span class="SpellE"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO, Patran</span></b></span><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 
     <!-- nic -><o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764242636<o:p></o:p></SPAN></B></P></TD>
   
<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">CDPO, Rajpura</SPAN></B></SPAN><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!--nic->
      <SPAN class=SpellE><!--nic-></SPAN><o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762223788<o:p></o:p></SPAN></B></P></TD></TR></DIV>
       
 <P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
 style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>
--></span></b></p></td></tr></tbody></table>
<h2>Food Supply Department</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 330pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
<tbody>
  <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE:14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
     

 </tr><tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Director&nbsp;Patiala&nbsp;Div.&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752367066 Fax 2367066 <o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Food&nbsp;&amp;&nbsp;Supply&nbsp;Controller,&nbsp;Patiala&nbsp;1</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311317<o:p></o:p></span></b></p></td>
   
 </tr><tr style="mso-yfti-irow: ">    
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> District&nbsp;Food&nbsp;&amp;&nbsp;Supply&nbsp;Controller,&nbsp;Patiala&nbsp;2 <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311318</span></b></p></td>
   
</tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Distt&nbsp;Manager,&nbsp;Punsup,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215845<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: ">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Distt&nbsp;Manager,&nbsp;Markfed,&nbsp;Patiala <o:p></o:p></span></b></p></td>
   <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752373103 <o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow: ">
       <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Distt&nbsp;Manager,&nbsp;Punjab&nbsp;Agro,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752355238<o:p></o:p></span></b></p></td>
    
  
</tr><tr style="mso-yfti-irow: ">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Distt&nbsp;Manager,&nbsp;FCI,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752351675  01752351620<o:p></o:p></span></b></p></td>
   
</tr><tr style="mso-yfti-irow: //s; mso-yfti-lastrow: yes">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><span class="SpellE"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // ->
      </SPAN></B></SPAN><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> District&nbsp;Manager,&nbsp;Punjab&nbsp;State Warehousing&nbsp;Corporation,&nbsp;Patiala
     <!-- // -> <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752351182<o:p>&nbsp;</o:p></SPAN></B></P></TD></Table></DiV>
    
<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 15pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Punjab Mandi Board 
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>
<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 330pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
<TBODY>
  
<TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE:14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
    
 <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Mandi&nbsp;Officer,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01755026510 Fax 2358805 <o:p></o:p></SPAN></B></P></TD>
   
<TR style="mso-yfti-irow: ">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;District&nbsp;Mandi&nbsp;Officer,&nbsp;Patiala </o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01755081454<o:p></o:p></SPAN></B></P></TD>
    
<TR style="mso-yfti-irow: ">   
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752353032 01755081471</o:p></SPAN></B></P></TD>
    
<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Patran<o:p></o:p></SPAN></B></P></TD>
   
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764244626 01764242065<o:p></o:p></SPAN></B></P></TD>
    
<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Samana</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764226069 01764220054<o:p></o:p></SPAN></B></P></TD>
    
 <TR style="mso-yfti-irow: ">   
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Nabha<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01765220081 522545-46<o:p></o:p></SPAN></B></P></TD>
    
<TR style="mso-yfti-irow:">
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Rajpura <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762243327 01762500049 <o:p></o:p></SPAN></B></P></TD>
    
 <TR style="mso-yfti-irow: ">  
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Bhadson<O:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01765260107<o:p></o:p></SPAN></B></P></TD>
    
 <TR style="mso-yfti-irow: "> 
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Dakala<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752230504<o:p>&nbsp;</o:p></SPAN></B></P></TD>
   

   <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Dhudan&nbsp;Sadha<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752631615 01752632615<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    
<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary,&nbsp;Market&nbsp;Committee,&nbsp;Ghanour <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762267422 01762322880<o:p>&nbsp;</o:p></SPAN></B></P></TD></table></div>
    
<P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>
--></span></b></span></p></td></tr></tbody></table>
<h2>Judiciary</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
 <tbody>
  <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></span></b></p></td></tr>
 
 <tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212089<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212092
      <o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge&nbsp;1,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752211440<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge&nbsp;2,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752304324</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></span></b></p></td></tr>
  
<tr style="mso-yfti-irow: ">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge&nbsp;3,&nbsp;Patiala<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752303703<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></span></b></p></td></tr>
   
<tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge&nbsp;4,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752305633<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></span></b></p></td></tr>
 
 <tr style="mso-yfti-irow: ">  
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge&nbsp;5,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752304318<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></span></b></p></td></tr>
 
 <tr style="mso-yfti-irow: ">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge&nbsp;6,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212108 <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p>&nbsp;</o:p></span></b></p></td></tr>
  
<tr style="mso-yfti-irow: "> 
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&amp;&nbsp;Sessions&nbsp;Judge&nbsp;7,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215900<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- -><o:p></o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Distt.&nbsp;&&nbsp;Sessions&nbsp;Judge&nbsp;(A)/FTC,&nbsp;Patiala<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752302694<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p>&nbsp;</o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow: 10">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"></SPAN></B></SPAN><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Special&nbsp;Judge,&nbsp;CBI,&nbsp;Punjab,&nbsp;Patiala
      <SPAN class=SpellE></SPAN><o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212118<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"></SPAN></B></SPAN><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Presiding&nbsp;Officer,&nbsp;Industrial&nbsp;Tribunal,&nbsp;Patiala <SPAN class=SpellE></SPAN><o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752303055<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>
   
 
  <TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil&nbsp;Judge&nbsp;(Senior&nbsp;Division),&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752211921<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
 <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Judicial&nbsp;Magistrate,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752213005<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
   <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Civil&nbsp;Judge&nbsp;(Sr.&nbsp;Division),&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752304316<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil&nbsp;Judge&nbsp;1&nbsp;Junior&nbsp;Division,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752304322<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
  <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil&nbsp;Judge&nbsp;2&nbsp;Junior&nbsp;Division,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752204320<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil&nbsp;Judge&nbsp;3&nbsp;Junior&nbsp;Division,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752213383<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Special&nbsp;Judicial&nbsp;Magistrate,&nbsp;CBI,&nbsp;Punjab,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752213743<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Civil&nbsp;Judge&nbsp;(Senior&nbsp;Division),&nbsp;Nabha <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01765220679<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil&nbsp;Judge&nbsp;(Junior&nbsp;Division),&nbsp;Nabha <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01765226666<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Civil&nbsp;Judge&nbsp;(Senior&nbsp;Division),&nbsp;Samana <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764220746<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil&nbsp;Judge&nbsp;(Junior&nbsp;Division),&nbsp;Samana <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764220746<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>


<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Addl.&nbsp;Civil&nbsp;Judge&nbsp;(Senior&nbsp;Division),&nbsp;Rajpura <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762224563<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil&nbsp;Judge&nbsp;(Junior&nbsp;Division),&nbsp;Rajpura<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762241556<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Civil&nbsp;Judge&nbsp;(Senior&nbsp;Division),&nbsp;Rajpura<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762240528<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">   
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> District&nbsp;Attorney&nbsp;(P),&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752213715  <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>
 
<TR style="mso-yfti-irow: ">   
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Attorney&nbsp;(L),&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311113 01752311114 <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>

<P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>
--></span></b></p></td></tr></tbody></table>
<h2>Muncipal Corporation</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 330pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
  <tbody>
   <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    
 </tr><tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Mayor, Municipal&nbsp;Corporation,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752310010<o:p></o:p></span></b></p></td>
   

</tr><tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Commissioner, Municipal&nbsp;Corporation,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311326<o:p></o:p></span></b></p></td>
    
 </tr><tr style="mso-yfti-irow: ">    
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Assistant&nbsp;Commissioner, Municipal&nbsp;Corporation,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311327</span></b></p></td>
        
   </tr></tbody></table>
   <h2>Excise And Taxation Punjab</h2>
   <table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
  <tbody>
   <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></span></b></p></td></tr>
 
<tr style="mso-yfti-irow:">
  
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Excise&nbsp;&amp;&nbsp;Taxation&nbsp;Commissioner, Punjab&nbsp;H.O,&nbsp;Patiala <o:p></o:p></span></b></p></td>   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212058 01752214036<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><a href="http://pextax.com/"> pextax.com </a><o:p></o:p></span></b></p></td></tr>
  

 <tr style="mso-yfti-irow: ">
    
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Excise&nbsp;&amp;&nbsp;Taxation&nbsp;Commissioner, Patiala&nbsp;Division,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752362456<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr> 

<tr style="mso-yfti-irow: ">
    
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Excise&nbsp;&amp;&nbsp;Taxation&nbsp;Commissioner(Appeal), Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752354340<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr> 


<tr style="mso-yfti-irow: ">

    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Assistant&nbsp;Excise&nbsp;&amp;&nbsp;Taxation&nbsp;Commissioner, Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311326<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
<tr style="mso-yfti-irow: ">

    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Additional&nbsp;Excise&nbsp;&amp;&nbsp;Taxation&nbsp;Commissioner&nbsp;1, Punjab, Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212066<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212067 
      <o:p></o:p></span></b></p></td></tr>
<tr style="mso-yfti-irow: ">

    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Joint&nbsp;Commissioner&nbsp;(X),&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752308002 <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
 
<tr style="mso-yfti-irow: ">

    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Additional&nbsp;Excise&nbsp;&amp;&nbsp;Taxation&nbsp;Commissioner(Admin.), Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212074 01752358072 <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ">

    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Excise&nbsp;&amp;&nbsp;Taxation&nbsp;Commissioner (VAT&nbsp;II)&nbsp;&amp;&nbsp;Dir.&nbsp;Investigation,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752304344 01752217212 <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ; mso-yfti-lastrow: yes">
   
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><span class="SpellE"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">D.E.T.C (Distillary)
      </span></b></span><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 
     <!-- // -> <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752301273 01752215836<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
    style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>

<P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>
--></span></b></p></td></tr></tbody></table>
<h2>Police Department</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
<tbody>
  <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">IG Zonal, Patiala   <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752303053 Fax:2311141<o:p>&nbsp;</o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311147<o:p></o:p></span></b></p></td></tr>
    

 <tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DIG&nbsp;Zonal,&nbsp;Patiala&nbsp;Range <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311144 Fax:2311142<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>


 <tr style="mso-yfti-irow: ">
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">SSP, Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311112 Fax:2311113 <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">0175241300 0175241301<o:p>&nbsp;</o:p></span></b></p></td></tr>
 
<tr style="mso-yfti-irow: ">  
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> SP,  HQ Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311124<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- -><o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">SP, Detective Patiala<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311128<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p>&nbsp;</o:p></SPAN></B></P></TD></TR>

 
<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"></SPAN></B></SPAN><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> SP, /Ops Patiala
      <SPAN class=SpellE></SPAN><o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311126<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>
 
  <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">SP, City Patiala
     <!-- // -> <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311129<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">   
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP, Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752303839</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP, Patiala<o:p></o:p></SPAN></B></P></TD>
   
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752218811<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>
  
 <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP,  HQ PAT <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311146<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
 <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP, Detective Patiala
     <!-- // -> <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311140<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> DSP, City Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311136<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
  <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP, City-II, Patiala<!-- // -> <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311134<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
    
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP Rural, Patiala
      <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311131<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP,  Nabha<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01765220662<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
 
 <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP,  Samana<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764220386<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DSP,   Patran<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01764242025<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> DSP, Rajpura<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01762220160<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>
  

<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Others 
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>
<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
<TBODY>
  <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
   
<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">DIG&nbsp;Railway&nbsp;&&nbsp;&nbsp;Punjab&nbsp;Chandigarh</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212038<o:p></o:p></SPAN></B></P></TD>
   
<TR style="mso-yfti-irow:">
      <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">I.G.&nbsp;Railway&nbsp;Police&nbsp;Force,&nbsp;Punjab,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752212050<o:p></o:p></SPAN></B></P></TD>
    
<TR style="mso-yfti-irow: ">   
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Commandant,&nbsp;Punjab&nbsp;Home&nbsp;Guard,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752212184 <o:p></o:p></SPAN></B></P></TD>
   
<TR style="mso-yfti-irow: ">   
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Superintendent,&nbsp;Centeral&nbsp;Jail,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752366546 <o:p></o:p></SPAN></B></P></TD>
   <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">SSP,&nbsp;Vigilance,&nbsp;&nbsp;Patiala&nbsp;Range,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752302027 01752303839 01752303840<o:p></o:p></SPAN></B></P></TD></Table></div>
       
  <P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
  style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>
--></span></b></p></td></tr></tbody></table>
<h2>Health Service</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
  <tbody>
   <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    
 
  </tr><tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Civil Surgeon, Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752211619<o:p>&nbsp;</o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><span class="SpellE"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Medical Officer, Patiala </span></b></span><b><span style="FONT-SIZE: 10pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <span class="SpellE"></span><o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752219854<o:p></o:p></span></b></p></td>
   

 </tr><tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Medical&nbsp;Superintendent, Rajindra&nbsp;Hospital,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212542 01752361971<o:p></o:p></span></b></p></td>
   
</tr><tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Emergency&nbsp;(EMO), Rajindra&nbsp;Hospital,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01755005515 01752214971<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow:">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Emergency&nbsp;(Gyane), Rajindra&nbsp;Hospital,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752213217</span></b></p></td>
    
</tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Medical&nbsp;Superintendent, Ayurvedic&nbsp;Hospital,&nbsp;Patiala<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212383<o:p></o:p></span></b></p></td>
   
</tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Mata&nbsp;Kaushalya&nbsp;Hospital,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752222481 01752201600<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Saket Hospital, Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752200319 01752213385<o:p></o:p></span></b></p></td>
    
 </tr><tr style="mso-yfti-irow:">
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Deputy&nbsp;Medical&nbsp;Superintendent, T.B.&nbsp;Hospital,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752220268 01752220257 <o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow:"> 
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Govt.&nbsp;Ayurvedic&nbsp;Hospital,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212019<o:p></o:p></span></b></p></td></tr></tbody></table>
      <h2>PSPCL</h2>
      <table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
  <tbody>
   <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></span></b></p></td></tr>
 
 <tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chairman&nbsp;Cum&nbsp;Managing&nbsp;Director,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212005 Fax:2213199<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752206414<a href="http://www.pspcl.in "> www.pspcl.in  <o:p></o:p></a></span></b></p></td></tr> 
<tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director/Administration,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212001 01752214639 <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> <o:p></o:p></span></b></p></td></tr> 
<tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director/Finance,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752213162<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752280144 <o:p></o:p></span></b></p></td></tr> 
<tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director/Generation,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215764 Fax2301756<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> <o:p></o:p></span></b></p></td></tr> 
<tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Director/Human&nbsp;Resources,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">2220491<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752218385 <o:p></o:p></span></b></p></td></tr> 
<tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director/Commercial,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752200180 Fax 2200140<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752214936 <o:p></o:p></span></b></p></td></tr> 
<tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director/Distribution,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 2200161 Fax 2212069<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752206414 <o:p></o:p></span></b></p></td></tr> 
<tr style="mso-yfti-irow:">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">P.A.&nbsp;(Camp&nbsp;Office),&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752206414<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></span></b></p></td></tr>
 
 <tr style="mso-yfti-irow:">    
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">OSD &amp; CMD,  Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215497</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></span></b></p></td></tr></tbody></table>
      <h2>Education</h2>
      <table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 370pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
 <tbody>
 
 <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></span></b></p></td></tr>
 
 <tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">District&nbsp;Education&nbsp;Officer,&nbsp;(Secondary),&nbsp;Patiala  <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215222<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
 
<tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> District&nbsp;Education&nbsp;Officer,&nbsp;(Elementary),&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752225863<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
 
<tr style="mso-yfti-irow: ">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Govt.&nbsp;ITI&nbsp;Head&nbsp;Master,&nbsp;Group&nbsp;B,&nbsp;Patiala<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752203324<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Govt.&nbsp;Mohindra&nbsp;College,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752321516 01752321695<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752321191<o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow:">  
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Multani&nbsp;Mal&nbsp;Modi&nbsp;College,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752214108<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- -><o:p></o:p></SPAN></B></P></TD></TR>
 

<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Govt.&nbsp;Bikram&nbsp;College&nbsp;of Commerce,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752220493 Fax:2307797 <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;P.&nbsp;Gursevak&nbsp;Singh,&nbsp;Physical Education&nbsp;College,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752228303<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal&nbsp;Khalsa&nbsp;College,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215835<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow: ">
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 10.80pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director,&nbsp;Thapar&nbsp;University,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752393001 01752363007 <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><A HREF="http://www.thapar.edu">www.thapar.edu</A><o:p>&nbsp;</o:p></SPAN></B></P></TD></TR>
  
<TR style="mso-yfti-irow:">
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 10.80pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Thapar&nbsp;Polytechnic&nbsp;College,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752393001 <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p>&nbsp;</o:p></SPAN></B></P></TD></TR>
  
 <TR style="mso-yfti-irow:"> 
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Executive&nbsp;Director,&nbsp;Netaji&nbsp;Subash&nbsp;National&nbsp;Institute of&nbsp;Sports,&nbsp;Patiala <o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212070 01752215289<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><A HREF="http://www.nsnis.org/">www.nsnis.org/<o:p>&nbsp;</o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"></SPAN></B></SPAN><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Govt.&nbsp;Medical&nbsp;College,&nbsp;Patiala <SPAN class=SpellE></SPAN><o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212018 01752212055<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>
     
<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"></SPAN></B></SPAN><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">National&nbsp;Institute&nbsp;of&nbsp;Ayurvedic&nbsp;Pharmaceutical Research,&nbsp;Patiala<SPAN class=SpellE></SPAN><o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212393 01752228361<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></SPAN></B></P></TD></TR>
   
   <TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Principal,&nbsp;Govt.&nbsp;Polytechnic&nbsp;College&nbsp;for Girls,&nbsp;SST&nbsp;Nagar,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752370158<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
  

 
<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Govt.&nbsp;College&nbsp;for&nbsp;Women,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752222189 01752213228<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Govt.&nbsp;Ayurvedic&nbsp;College,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212019<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Govt.&nbsp;Industrial&nbsp;Training&nbsp;Institute, Near&nbsp;Malwa&nbsp;Cinema,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752201143<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>
<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Govt.&nbsp;Industrial&nbsp;Training&nbsp;Institute, Model&nbsp;Town,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752200301<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR>

  
<TR style="mso-yfti-irow:; mso-yfti-lastrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><SPAN class=SpellE><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Principal,&nbsp;Yadvindra&nbsp;Public&nbsp;School,&nbsp;Patiala  
      </SPAN></B></SPAN><B><SPAN style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 
     <!-- // -> <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215634<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
    style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><A HREF="http://www.ypspatiala.in">www.ypspatiala.in <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>

<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>

<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Punjabi University Patiala
<o:p></o:p></SPAN></U></B></P>


<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 370pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
  <TBODY>
   <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     <TD 
      style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
      vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No.</SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></SPAN></B></P></TD></TR>
 
<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Vice&nbsp;Chancellor, Punjabi&nbsp;University,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01753046001 01753046005 01753046150 01753046303<o:p>&nbsp;</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><A HREF="http://punjabiuniversity.ac.in">punjabiuniversity.ac.in</A> <o:p></o:p></SPAN></B></P></TD></TR>
 
 <TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 11.0pt"> Registrar,&nbsp;Punjabi&nbsp;University&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01753046030 01752286416<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></SPAN></B></P></TD></TR> 

<TR style="mso-yfti-irow:">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Dean&nbsp;College&nbsp;Development, Punjabi&nbsp;University,&nbsp;Patiala </o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01753046165<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></SPAN></B></P></TD></TR>
 
 <TR style="mso-yfti-irow:">    
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Dean&nbsp;Student&nbsp;Welfare,  Punjabi&nbsp;University,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01753046415</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></SPAN></B></P></TD></TR> 
    
<TR style="mso-yfti-irow:">    
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Controller&nbsp;Examination, Punjabi&nbsp;University&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01753046370</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></SPAN></B></P></TD></TR> 
  
<TR style="mso-yfti-irow:">    
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director&nbsp;Public&nbsp;Relation&nbsp;Officer, Punjabi&nbsp;University,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01753046230</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></SPAN></B></P></TD></TR> 
    
<P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>
--></span></b></p></td></tr></tbody></table>
<h2>PWD B &amp; R Branch</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 350pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
  <tbody>
   <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></span></b></p></td></tr>
  <tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer,&nbsp;(H.O&nbsp;&amp;&nbsp;N.H.),&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752362545<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01722260266<a href="http://pwdpunjab.gov.in"> pwdpunjab.gov.in </a>
      <o:p></o:p></span></b></p></td></tr> 
<tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer,&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752356245<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">0175212211<o:p></o:p></span></b></p></td></tr> 

<tr style="mso-yfti-irow: ">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief Engineer (Plan Roads) Punjab, Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752358280<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752200752<o:p></o:p></span></b></p></td></tr> 

<tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer, (Link&nbsp;Roads)&nbsp;Punjab,&nbsp;Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752236493<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
 <tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer,&nbsp;(Building)</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01722742239<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
 <tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer&nbsp;cum&nbsp;DQCC</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01722704613<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer Cum&nbsp;Tech.&nbsp;Advisor&nbsp;(PIDB)</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01722665565<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
 <tr style="mso-yfti-irow: ">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer (PRBDB)</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01726626620<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></span></b></p></td></tr>
 <tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer&nbsp;Electrical,&nbsp;Patiala<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752356293<o:p></o:p></span></b></p></td>
        <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>
<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Head Office Exchange No.Patiala
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>

<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 350pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
  <TBODY>
   <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     <TD 
      style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
      vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD></tr>
    
   <TR style="mso-yfti-irow: ">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer (PBX)</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752360003 01752360009 01752360023 01752357550 01752360039<o:p></o:p></SPAN></B></P></TD>
   </table></DIV>
 
<P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>

--></span></b></p></td></tr></tbody></table>
<h2>Other Important Departments</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: 0.05in; BORDER-LEFT: medium none; WIDTH: 390pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
  <tbody>
  <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></span></b></p></td></tr>

 
<tr style="mso-yfti-irow:">   
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Chairman&nbsp;(PRTC),&nbsp;Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311700  <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><a href="http://www.pepsurtc.gov.in">www.pepsurtc.gov.in</a><o:p></o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow: ">   
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Managing&nbsp;Director&nbsp;(PRTC),&nbsp;Patiala  <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311701  <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p></o:p></span></b></p></td></tr>
 
 <tr style="mso-yfti-irow:">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Director&nbsp;Language&nbsp;Department,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752214469 01752221568 </span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow:">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Punjab&nbsp;State&nbsp;Transmission Corporation&nbsp;Limited&nbsp;(H.O.),&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212053 01752307079 </span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow:">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">M.D,&nbsp;State&nbsp;Bank&nbsp;of&nbsp;Patiala, Head&nbsp;Office,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212010 01752215682 </span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><a href="http://www.sbp.co.in">www.sbp.co.in</a><o:p> </o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow:">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Senior&nbsp;Superintendent,&nbsp;Post&nbsp;Office, Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215557 </span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></span></b></p></td></tr>

<tr style="mso-yfti-irow:">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Senior&nbsp;Post&nbsp;Master,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752301697 </span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><o:p> </o:p></span></b></p></td></tr>


<tr style="mso-yfti-irow:">   
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">G.M, Bharat&nbsp;Sanchar&nbsp;Nigam&nbsp;Limited,&nbsp;Patiala <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> 01752309946</span></b></p></td>
       <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="90">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>



<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Punjab Public Service Commission, Patiala
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>

<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 390pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
  <TBODY>
  <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></SPAN></B></P></TD></TR>
 
 <TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chairman, PPSC</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01755011902<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
     style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><A HREF="http://www.ppsc.gov.in\">www.ppsc.gov.in </A>
      <o:p></o:p></SPAN></B></P></TD></TR> 

<TR style="mso-yfti-irow:">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Secretary, PPSC </o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01755014833<o:p></o:p></SPAN></B></P></TD>
        <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
   style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>

<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt"> Punjab Pollution Control Board, Vatavaran Bhawan, Patiala
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>

<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 390pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
 <TBODY>
  <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></SPAN></B></P></TD></TR>
 
 <TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chairman</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752215793 01752200557<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
     style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><A HREF="http://www.ppcb.gov.in/">www.ppcb.gov.in </A>
      <o:p></o:p></SPAN></B></P></TD></TR> 

<TR style="mso-yfti-irow:">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Member Secretary </o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">1752215802<o:p></o:p></SPAN></B></P></TD>
        <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
   style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>


<DIV class=Section1>
 <P class=MsoNormal 
  style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
   style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Water Supply & Sewerage Board
 <o:p></o:p></SPAN></U></B></P>
 <P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
 style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
 style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
 </SPAN><o:p></o:p></SPAN></B></P>
<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 390pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
<TBODY>
  <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Residence/URL<o:p></o:p></SPAN></B></P></TD></TR>
 

 <TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer, Water&nbsp;Supply&nbsp;&&nbsp;Sanitaion,&nbsp;Patiala&nbsp;(South)<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212039<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><A HREF="http://www.pwssb.com">www.pwssb.com</A>

<TR style="mso-yfti-irow:">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Engineer, Water&nbsp;Supply&nbsp;&&nbsp;Sanitaion,&nbsp;Patiala&nbsp;(North)</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212029<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></SPAN></B></P></TD></TR>

<TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Superintendent&nbsp;Engineer,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752213054<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></SPAN></B></P></TD></TR> 

<TR style="mso-yfti-irow:">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Executive&nbsp;Engineer,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752228272<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">
      <o:p></o:p></SPAN></B></P></TD></TR>
 
 <TR style="mso-yfti-irow:">    
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Executive&nbsp;Engineer,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752222617</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752304889<o:p> </o:p></SPAN></B></P></TD></TR> 

<TR style="mso-yfti-irow:">
  <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Executive&nbsp;Engineer,&nbsp;Division&nbsp;2,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
   
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752221171<o:p></o:p></SPAN></B></P></TD>
        <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 67.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=90>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
    style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><!-- // -> <o:p></o:p></SPAN></B></P></TD></TR></TBODY></TABLE></DIV>
<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief Electrical (H.O.), Patiala
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>
<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 390pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
   <TBODY>
  <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
   
 <TR style="mso-yfti-irow:">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chief&nbsp;Electrical&nbsp;Inspector,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212107<o:p></o:p></SPAN></B></P></TD>
   

<TR style="mso-yfti-irow:">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Executive&nbsp;Engineer,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752359072<o:p></o:p></SPAN></B></P></TD>
       </TR></TBODY></TABLE></DIV>


<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Architect Department (South & North)
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>

<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 390pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
  <TBODY>
  <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
    

 <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Architect(South)<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752200452<o:p></o:p></SPAN></B></P></TD>
   

<TR style="mso-yfti-irow:">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
     
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Architect(North)</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752200480<o:p></o:p></SPAN></B></P></TD>
       </TR></TBODY></TABLE></DIV>


<P class=MsoNormal 
style="TEXT-ALIGN: Center; tab-stops: right 6.0in"><B><U><SPAN 
style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Improvement Trust Patiala
<o:p></o:p></SPAN></U></B></P>
<P class=MsoNormal style="TEXT-ALIGN: justify; tab-stops: right 6.0in"><B><SPAN 
style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt"><SPAN 
style="mso-tab-count: 1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
</SPAN><o:p></o:p></SPAN></B></P>

<DIV align=center>
<TABLE class=MsoNormalTable 
style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 390pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" 
cellSpacing=0 cellPadding=0 width=516 border=1>
  
  <TBODY>
  <TR style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</SPAN></B></P></TD>
    
 
 <TR style="mso-yfti-irow: ">
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Chairman, Improvement&nbsp;Trust,&nbsp;Patiala<o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752212093<o:p></o:p></SPAN></B></P></TD>
   

<TR style="mso-yfti-irow: ">
<TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Executive&nbsp;Officer, Improvement&nbsp;Trust,&nbsp;Patiala</o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01755062241<o:p></o:p></SPAN></B></P></TD>
    
 
 <TR style="mso-yfti-irow:">    
 <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=162>
      
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Engineer, Improvement&nbsp;Trust,&nbsp;Patiala <o:p></o:p></SPAN></B></P></TD>
    <TD 
    style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" 
    vAlign=top width=84>
      <P class=MsoNormal style="TEXT-ALIGN: justify"><B><SPAN 
      style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01755062240</o:p></SPAN></B></P></TD>
       </TABLE></DIV>

<P class=MsoNormal style="MARGIN-RIGHT: -63pt; TEXT-ALIGN: justify"><SPAN 
style="COLOR: navy"><o:p>&nbsp;</o:p></SPAN></P></DIV></BODY></HTML>
--></span></b></p></td></tr></tbody></table>
<h2>Other Enquiries</h2>
<table class="MsoNormalTable" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BACKGROUND: #fce9ca; MARGIN-LEFT: -0.05in; BORDER-LEFT: medium none; WIDTH: 320pt; BORDER-BOTTOM: medium none; BORDER-COLLAPSE: collapse; mso-border-alt: solid windowtext .5pt; mso-padding-alt: 0in 5.4pt 0in 5.4pt; mso-border-insideh: .5pt solid windowtext; mso-border-insidev: .5pt solid windowtext" cellspacing="0" cellpadding="0" width="516" border="1">
  
  <tbody>
   <tr style="mso-yfti-irow: 0; mso-yfti-firstrow: yes">
     <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Designation<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: windowtext 1pt solid; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 14pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Office No</span></b></p></td>
    
 </tr><tr style="mso-yfti-irow:">
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Bus Stand, Patiala<o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752311718<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow:">
<td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Railway Station, Patiala</span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">131 132<o:p></o:p></span></b></p></td>
     
 </tr><tr style="mso-yfti-irow:">    
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
      
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Police Station <o:p></o:p></span></b></p></td>
    <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">100</span></b></p></td>
   
</tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Fire<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">101<o:p></o:p></span></b></p></td>
    
</tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Ambulance<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">108<o:p></o:p></span></b></p></td>

</tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Flood Control Room<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752350097<o:p></o:p></span></b></p></td>
 
   
  </tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Emergency&nbsp;(Rajindra&nbsp;Hospital)<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">01752214971 <o:p></o:p></span></b></p></td>
    
  </tr><tr style="mso-yfti-irow:">
  <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: windowtext 1pt solid; WIDTH: 121.5pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="162">
     
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">Telephone Inquiry<o:p></o:p></span></b></p></td>
   
 <td style="BORDER-RIGHT: windowtext 1pt solid; PADDING-RIGHT: 5.4pt; BORDER-TOP: medium none; PADDING-LEFT: 5.4pt; PADDING-BOTTOM: 0.1in; BORDER-LEFT: medium none; WIDTH: 63pt; PADDING-TOP: 0.1in; BORDER-BOTTOM: windowtext 1pt solid; mso-border-alt: solid windowtext .5pt; mso-border-left-alt: solid windowtext .5pt; mso-border-top-alt: solid windowtext .5pt" valign="top" width="84">
      <p class="MsoNormal" style="TEXT-ALIGN: justify"><b><span style="FONT-SIZE: 11pt; COLOR: navy; mso-bidi-font-size: 12.0pt">197 <o:p></o:p></span></b></p></td></tr></tbody></table>