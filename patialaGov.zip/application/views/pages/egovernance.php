
<h2>E-GOVERANCE IN PATIALA<h2>

<p align="JUSTIFY">
For implementing E-Governance in India, National Informatics Centre was established with its Headquarters at New Delhi, State Units in all the 28 State capitals and 7 Union Territory Headquarters and District centres in almost all the Districts of India. The Organization employs a large pool of efficient technical manpower.</p>
<h2>NIC IN Patiala</h2>

<p align="justify">
NIC Patiala was established in 1989 with objective of implementing e-goverance in District Patiala
</p>
<p align="justify"><b>Video Conferencing Studio:</b> Video Conferencing facility had been set up at NIC Patiala. A number of VCs are conducted for district, with State HQ as well as with various offices of Govt. of India etc. </p>

<p align="justify"><b>PRISM  (Property Registration Information System Module): </b>This project is to computerize the Sub Registrar Office of the District.This project had been implemented at 8 locations (5 Tehsils and 3 Sub Tehsils) in District Patiala . On the spot, snaps of the purchaser,buyer and witness are taken and deed done on the computer.</p>

<p align="justify"><b>SUWIDHA :</b> SUWIDHA (Single User Window Disposal Helpline for Applicants)is single window service to deliver District Administration services to the Citizens. The technical support is provided for the smooth running of SUWIDHA SW and its backend applications running at SUWIDHA Centre.</p>

<p align="justify"><b>Treasury Information System:</b> NIC has fully computerized the Treasury of District Patiala. All work like Bills, Accounts, data transfer, receipt, Pension, daily data from banks, maintaining of budget etc has been computerized and running successfully since 2001. This has drastically reduce he work of Treasury Employees as now they do not have to calculate the complex figure daily. Almost all the things have been done by the Software itself. Payments Check also now been printed. It brings relief from the hectic and complex work of Treasury and also the payments check has been given to the carious departments in time.</p>
<p align="justify"><b>e-Courts:</b> e-Court Project had been implemented in the district court and subordinates court of Patiala . All the court case  work starting from the Case filing, case allocation, allotment of cases, order printing, Judgment writing are computerized. </p>
<p align="justify"><b>ALIS(Arms License Information System) </b>The PLA branch of DC office dealing with Arms Licenses is computerized.  For the issue of new arms license, on the spot snap of applicant is taken, printing taken on stickers and stickers are pasted on arms license copy.</p>
<p align="justify">
<b>AGMARKNET </b>  has been implemented in all the tweleve  market committees of Patiala District. Rates of various commodities are entered and put on agmarknet.nic.in web site.</p> 
<p align="justify">
<b>PRTC</b> One depot of Pepsu Road Transport Corporation is computerized. The way bills of conductors have been computerized.</p>
<p align="justify">
<b>DMS(Dak Monitoring System) </b>  keeps track of   DO letters  and important letters received by DC from different departments. Officers wise pending list, monthly pending cases list, disposed cases lists are generated.</p>
<p align="justify">
<b>CSMS(Co-operative society Management system) </b> has been implemented.  Yearly data entry is done for all three parts namely Statement-I, Statement-II &amp;  Statement-III  (RBI-Tables), printouts taken and complete data was sent  to  State  Headquarters.</p>
 
<p align="justify">
<b>MPLAD</b>  package keeps track of funds spent on different local area development schemes by the MPs. 
</p>
<p align="justify"><b>0029 Statement</b> prepares the report required for monthly meeting of revenue Officers reg. State Tax. </p>

<p align="justify"><b>FCI: </b>The FCI office is computereised. Wagon Information System, Payroll system has been computerised. 
</p>
<p align="justify"><b>DSSO Office:</b> Government of Punjab is giving monthly pensions to Old Age persons Widows, Dependent children and Disabled persons. More then sixty thousand lakh beneficiaries are there in District Patiala. NIC has successfully computersied all the pension details  which results in the timely distribution of the pension to the beneficiaries. This will drastically reduce the work of District Social Security Office. </p>
<p align="justify"><b>Village Directory Information System :</b> Deputy Economic and Statistical Advisor’s ( Dy. E.S.A.) office is maintaining the Village directory of all the villages of District Patiala  which consists all the possible data of the villages. NIC has also computerized this Village directory and in operation for the past 10 years.</p>
<p align="justify"><b>AISES Education Survey:</b> Computerisation of Education survey for all schools of the Urban and Rural areas of district Patiala is being done for previous many years continuously.</p>
<p align="justify"><b>PAYROLL  :</b> Software for pay of the employees of the Deputy Commissioners Office has been implemented by NIC Patiala  for many years. Now the pay bills will be done in few hours previously it will take weeks.
</p>
<p align="justify"><b>GPF"</b> GPF statements for all the class III and Class  ClassIV staff generated through GPF Sw .

</p><p align="justify">
<b>RURAL SOFT:</b> This is the new On line project in which entries of all the Rural development schemes is to be entered directly on web site developed by NIC by DRDA and Zila Parishad officials.</p>
<p align="justify"><b>Election Work:</b> All the technical work like Deployment of Polling Staff, Reports, Afidavits scaning and Result of Vidhan Sabha, Lok Sabha, Panchayat, Zila Parishad, Gurudwara Elections has been done by NIC for several years.</p>

<p align="justify">
<b>Sarathi and Vahan :</b> Sarathi is the Driving License Software implemented successfully in the DTO Office Patiala and Vahan is a software for registration of Vehicles is also successfully implemented in the DTO office, Patiala.Smart cards are issued for driving Licenses and  Registration of Vehicles.</p>
<p align="justify"><b>Online National Permit Software:</b>Online National Permit Sw for Goods Carriage is implemented successfully in the Secy. Regional Transport Authority, Patiala as Pilot Project .</p>