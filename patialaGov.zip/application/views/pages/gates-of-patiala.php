		<h3>Gates In Patiala</h3>
			<p>&nbsp;&nbsp;Maharaja Narendra Singh (1845–1862) fortified the city of Patiala 
			by constructing ramparts and ten gates around the city:</p>
			 <br/>
				<ul >
					<li>Darshani gate - Main entrance of Qila Mubarak</li>
					<li>Lahori gate</li>
					<li>Nabha Gate</li>
					<li>Samania Gate</li>
					<li>Sirhindi Gate</li>
					<li>Safabadi Gate</li>
					<li>Sheranwala Gate</li>
					<li>Sunami Gate</li>
					<li>Top Khana Gate</li>
					<li>Sanauri Gate</li>
				</ul>
				<marquee behavior="ALTERNATE" loop="3" onmouseover="this.stop()" onmouseout="this.start()" scrollamount="5">

				<img src="../images\darshani.JPG" width="200px" border="0" >
				<img src="../images\samania.JPG" width="200px" border="0">
				<img src="../images\sanauri.jpg" width="200px" border="0">
				<img src="../images\Sheran.JPG" width="200px" border="0">
				<img src="../images\sirhindi.JPG" width="200px" border="0">
				<img src="../images\sunami.JPG" width="200px" border="0">
				</marquee>
		