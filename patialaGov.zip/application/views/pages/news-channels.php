<h3>News Channels &amp; NewsPapers </h3>
<ul>
<li><a target="_BLANK" href="http://www.ddinews.com">DoorDarshan News</a></li>
<li><a target="_BLANK" href="http://www.ndtv.com">NDTV</a></li>
<li><a target="_BLANK" href="http://www.aajtak.com">Aaj Tak</a></li>
<li><a target="_BLANK" href="http://www.zeenews.com">Zee News</a></li>
<li><a target="_BLANK" href="http://www.bbc.co.uk">BBC</a></li>
<li><a target="_BLANK" href="http://www.cnn.com">CNN</a></li>

<li><a target="_BLANK" href="http://www.ajitjalandhar.com">Ajit Punjabi Newspaper </a></li>
<li><a target="_BLANK" href="http://www.amarujala.com">Amar Ujala</a></li>
<li><a target="_BLANK" href="http://www.jagran.com">Dainik Jagran</a></li>
<li><a target="_BLANK" href="http://www.punjabkesari.in">Punjab Kesri Newspaper Jal</a></li>
<li><a target="_BLANK" href="http://www.jagbani.in/">Jagbani Newspaper</a></li>

<li><a target="_BLANK" href="http://www.tribuneindia.com">Tribune</a></li>
<li><a target="_BLANK" href="http://www.timesofindia.com">Times of India</a></li>
<li><a target="_BLANK" href="http://www.indianexpress.com">Indian Express</a></li>
<li><a target="_BLANK" href="http://www.hindustantimes.com">Hindustan Times</a></li>
<li><a target="_BLANK" href="http://www.hindu.com">The Hindu</a></li>
<li><a target="_BLANK" href="http://www.asianage.com">Asian Age</a></li>
<li><a target="_BLANK" href="http://www.thenewspapertoday.com">News Paper Today</a></li>
<li><a target="_BLANK" href="http://www.deccanherald.com">Deccan Herald</a></li>
<li><a target="_BLANK" href="http://www.pioneer.com">Pioneer</a></li>

<li><a target="_BLANK" href="http://www.indiaexpress.com">India Express</a></li>
<li><a target="_BLANK" href="http://www.i4donline.net">Print and Online</a></li>
</ul>


