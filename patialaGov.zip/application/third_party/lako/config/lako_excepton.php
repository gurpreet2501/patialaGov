<?php
lako::get('config')->add_config('lako_exception',array(
  'write_to_file' => false,
  'file_name'     => ''
));