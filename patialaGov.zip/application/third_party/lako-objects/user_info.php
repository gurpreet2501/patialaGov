<?php
lako::get('objects')->add_config('user_info',array(
  "table"     => "user_info",
  "name"      => "user_info",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()
));