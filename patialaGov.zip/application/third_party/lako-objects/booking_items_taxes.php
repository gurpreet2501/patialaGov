<?php
lako::get('objects')->add_config('booking_items_taxes',array(
  "table"     => "booking_items_taxes",
  "name"      => "booking_items_taxes",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()
));