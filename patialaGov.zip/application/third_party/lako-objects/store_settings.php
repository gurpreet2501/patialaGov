<?php
lako::get('objects')->add_config('store_settings',array(
  "table"     => "store_settings",
  "name"      => "store_settings",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array(
  )
));