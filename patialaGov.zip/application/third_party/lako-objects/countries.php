<?php

lako::get('objects')->add_config('countries',array(
  "table"     => "countries",
  "name"      => "countries",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => []

));