<?php
lako::get('objects')->add_config('shipment_export',array(
  "table"     => "shipment_export",
  "name"      => "shipment_export",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()
));