<?php
lako::get('objects')->add_config('payment_details',array(
  "table"     => "payment_details",
  "name"      => "payment_details",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()
));