<?php

lako::get('objects')->add_config('discount_types',array(
  "table"     => "discount_types",
  "name"      => "discount_types",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()

));