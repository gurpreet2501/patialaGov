<?php

lako::get('objects')->add_config('tax_types',array(
  "table"     => "tax_types",
  "name"      => "tax_types",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()

));