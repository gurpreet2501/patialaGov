<?php
lako::get('objects')->add_config('categories',array(
  "table"     => "categories",
  "name"      => "categories",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()
));