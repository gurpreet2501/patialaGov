<?php
lako::get('objects')->add_config('booking_items_discounts',array(
  "table"     => "booking_items_discounts",
  "name"      => "booking_items_discounts",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array(
  )
));