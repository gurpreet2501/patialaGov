<?php

lako::get('objects')->add_config('customer_category_product_price',array(
  "table"     => "customer_category_product_price",
  "name"      => "customer_category_product_price",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => []

));