<?php
lako::get('objects')->add_config('shipment_domestic',array(
  "table"     => "shipment_domestic",
  "name"      => "shipment_domestic",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()
));