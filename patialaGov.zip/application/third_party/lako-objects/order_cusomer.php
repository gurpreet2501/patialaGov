<?php

lako::get('objects')->add_config('order_customer',array(

  "table"     => "order_customer",

  "name"      => "order_customer",

  "pkey"      => "id",

  "fields"    => array(),

  "relations" => array()

));