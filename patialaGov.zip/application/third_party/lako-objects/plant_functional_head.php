<?php
lako::get('objects')->add_config('plant_functional_head',array(
  "table"     => "plant_functional_head",
  "name"      => "plant_functional_head",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => array()
));