<?php

lako::get('objects')->add_config('cities',array(
  "table"     => "cities",
  "name"      => "cities",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => []

));