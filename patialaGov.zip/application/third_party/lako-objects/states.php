<?php

lako::get('objects')->add_config('states',array(
  "table"     => "states",
  "name"      => "states",
  "pkey"      => "id",
  "fields"    => array(),
  "relations" => []

));