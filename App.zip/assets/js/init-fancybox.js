$(document).ready(function() {
	$(".fancy").fancybox({
    'onCleanup':function(){}
  });
}); 